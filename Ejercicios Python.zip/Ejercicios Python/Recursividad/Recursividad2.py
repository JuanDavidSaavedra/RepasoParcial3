
def potencia(base, p):
    if (p==0):
        return 1
    else:
        return base*potencia(base, p-1)

base = int(input("Digite una base: "))
p = int(input("Digite un exponente: "))
print("La potencia de", str(base), "es", potencia(base, p))
