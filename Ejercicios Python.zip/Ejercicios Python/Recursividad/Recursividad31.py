# Ejercicio 3: Crear una función recursiva para sumar los números de una lista.

import random as random
rango = 50
rangoRandomicos = 1000
valores = []

for i in range(rango):
    valores.append(random.randint(0,rangoRandomicos))

print("La lista de números es: ", valores)

def sumar_lista(numeros):
    if len(numeros) == 0:
        return 0
    else:
        return numeros[0] + sumar_lista(numeros[1:])

resultado = sumar_lista(valores)

print('La suma es igual a: ', resultado)