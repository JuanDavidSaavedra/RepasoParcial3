numbers = [0,2,3,4,5,1,2]
resp = []
for number in numbers:
    # insertas el valor de la operacion
    resp.append(number % 2)
return resp