import numpy as np

a = np.array([[5,2], [1,4]])
b = np.array([9,9])

print(np.linalg.solve(a,b))
