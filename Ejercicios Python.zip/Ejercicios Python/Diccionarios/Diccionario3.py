opcion1 = {"Hamburguesa": 12000, "Papas fritas": 5000}
opcion2 = {"Salchipapa": 10000, "Plátanos fritos": 4000}
d = {"Opción 1: " : opcion1, "Opción 2: " : opcion2}
print(d)
#{'anidado1': {'a': 1, 'b': 2}, 'anidado2': {'a': 1, 'b': 2}}