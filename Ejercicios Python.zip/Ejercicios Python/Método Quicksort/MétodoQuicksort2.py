import random as random
from time import time

acu=0
n = int(input("Digite n: "))
while n<=0:
    print("Numero incorrecto, debe ser mayor que 0")
    n = int(input("Digite n: "))
    
inicio = time()
x=[]
c=0

while c!=n:
    z = random.randint(1,100)
    if z%2 == 0:
        x.append(z)
        acu+=z
        c += 1
        
if n>0:
    pro=acu/n
    
cele=0
for i in range(n):
    if x[i]<pro:
        cele+=1

a=[]
if cele<n/2:
    a = sorted(x)
    print("vector ordenado: ",a)
    
print("vector desordenado: ", x)

tiempo = time() - inicio
print("Tiempo de ejecucción: ", tiempo)




