import random as random
from time import time

inicio= time()
x=[]
c=6000
for i in range(c):
    x.append(random.randint(0,2000))

for i in range(1,c):
    for j in range(0,c-i):
        if(x[j+1] < x[j]):
            aux=x[j]
            x[j]=x[j+1]
            x[j+1]=aux

tiempo = time() - inicio
print("Tiempo de ejecucción: " + str(tiempo))